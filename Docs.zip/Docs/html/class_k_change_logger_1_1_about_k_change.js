var class_k_change_logger_1_1_about_k_change =
[
    [ "AboutKChange", "class_k_change_logger_1_1_about_k_change.html#a0edff4a5dce54be5dd1d32fb4d22d501", null ],
    [ "Dispose", "class_k_change_logger_1_1_about_k_change.html#aac5e742892a7a59cd6b7572ecb3ead10", null ],
    [ "InitializeComponent", "class_k_change_logger_1_1_about_k_change.html#a239bafda7a85ce466ad9ca7fe7356468", null ],
    [ "okButton_Click", "class_k_change_logger_1_1_about_k_change.html#aa474fbd13fc3b3c4ac68c60694b497d6", null ],
    [ "components", "class_k_change_logger_1_1_about_k_change.html#aed81bf0b7bbf5774cf0020d84abfdea0", null ],
    [ "labelCompanyName", "class_k_change_logger_1_1_about_k_change.html#abf5ab7ac0ea0973979f1fa6c352f50d5", null ],
    [ "labelCopyright", "class_k_change_logger_1_1_about_k_change.html#abaa7eeff42f48016f1ee959c8dedfefe", null ],
    [ "labelProductName", "class_k_change_logger_1_1_about_k_change.html#acdf353e65dc89188a905ea40b725bc54", null ],
    [ "labelVersion", "class_k_change_logger_1_1_about_k_change.html#a5e6bdb31d3fe806d17b02bb531b1f590", null ],
    [ "logoPictureBox", "class_k_change_logger_1_1_about_k_change.html#a6cba8e5b3a4728a482e519bdfb4ec209", null ],
    [ "okButton", "class_k_change_logger_1_1_about_k_change.html#ab70807d82884e278e44393f52bf6473e", null ],
    [ "tableLayoutPanel", "class_k_change_logger_1_1_about_k_change.html#acffa824c458a7ca7128450da284ab869", null ],
    [ "textBoxDescription", "class_k_change_logger_1_1_about_k_change.html#a3fc189a4aacb1fb11652f6fabbd36f16", null ],
    [ "AssemblyCompany", "class_k_change_logger_1_1_about_k_change.html#a281dd5da7c7531efa0b512d135e3b92f", null ],
    [ "AssemblyCopyright", "class_k_change_logger_1_1_about_k_change.html#aad45d239d293b32c0fa36c22931f9736", null ],
    [ "AssemblyDescription", "class_k_change_logger_1_1_about_k_change.html#a53422885f8632b73140971fd93be57b3", null ],
    [ "AssemblyProduct", "class_k_change_logger_1_1_about_k_change.html#afcf017de5cb2e3d50d52d7b2f7db108d", null ],
    [ "AssemblyTitle", "class_k_change_logger_1_1_about_k_change.html#a48c19b4363963314a03f796aeb97a3c1", null ],
    [ "AssemblyVersion", "class_k_change_logger_1_1_about_k_change.html#a502a36adf2930b23b738c2c37b7c5b95", null ]
];