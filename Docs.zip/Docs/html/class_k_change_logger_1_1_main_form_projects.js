var class_k_change_logger_1_1_main_form_projects =
[
    [ "MainFormProjects", "class_k_change_logger_1_1_main_form_projects.html#a60393e7a098488fc5afc21b3bf18fe95", null ],
    [ "CancelButton_Click", "class_k_change_logger_1_1_main_form_projects.html#a6bcd930ec84a32e6a220e59fd078a185", null ],
    [ "DeleteButton_Click", "class_k_change_logger_1_1_main_form_projects.html#a82d4274c1ee8e74403e283039bd70b55", null ],
    [ "Dispose", "class_k_change_logger_1_1_main_form_projects.html#afa56d89303d71f06763ecc768b507172", null ],
    [ "InitializeComponent", "class_k_change_logger_1_1_main_form_projects.html#a042dbeeb071bdbb843116558089c7b94", null ],
    [ "NewButton_Click", "class_k_change_logger_1_1_main_form_projects.html#a394a582d0f0fb8f97eeed9ac73e7bac7", null ],
    [ "ProjectsGV_CellClick", "class_k_change_logger_1_1_main_form_projects.html#a0c301440f2d5b4da344c7f69347a5281", null ],
    [ "ProjectsGV_CellContentClick", "class_k_change_logger_1_1_main_form_projects.html#a935f3d703b07e502089309b1e885cf3c", null ],
    [ "ProjectsGV_CellDoubleClick", "class_k_change_logger_1_1_main_form_projects.html#abfb59861d01b338d2ebf1b647e38c81d", null ],
    [ "RefreshButton_Click", "class_k_change_logger_1_1_main_form_projects.html#a194fc7933e0f1418ae641a5cbbc225e6", null ],
    [ "RefreshGridView", "class_k_change_logger_1_1_main_form_projects.html#ae15a6379717191a44cb10caa1557fbf9", null ],
    [ "ResizeColumns", "class_k_change_logger_1_1_main_form_projects.html#ac3a7eca526c10a839cc70b9c0a0d3666", null ],
    [ "CancelButton", "class_k_change_logger_1_1_main_form_projects.html#ad04fc1b58742d27b91ab2c02a5f0916e", null ],
    [ "components", "class_k_change_logger_1_1_main_form_projects.html#a9d5a3c99ed059204beb049fe0da60970", null ],
    [ "DeleteButton", "class_k_change_logger_1_1_main_form_projects.html#a84871e7da242657e7acf319ddcb3742b", null ],
    [ "myProject", "class_k_change_logger_1_1_main_form_projects.html#a47f329ca1c6a07ae17fa3f7a26aff687", null ],
    [ "NewButton", "class_k_change_logger_1_1_main_form_projects.html#ad1fff6d217dea5fe36205b88e70e4ac9", null ],
    [ "ProjectsGV", "class_k_change_logger_1_1_main_form_projects.html#a22c8e5d114d6cb95e0e63a964f7fc37e", null ],
    [ "RefreshButton", "class_k_change_logger_1_1_main_form_projects.html#a496c6071978df1563790331a88f2e737", null ]
];