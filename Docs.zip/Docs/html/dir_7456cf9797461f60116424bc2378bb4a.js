var dir_7456cf9797461f60116424bc2378bb4a =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs_source.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs_source.html", null ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs_source.html", null ]
];