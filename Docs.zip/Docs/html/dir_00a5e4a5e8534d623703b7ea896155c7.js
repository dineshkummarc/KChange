var dir_00a5e4a5e8534d623703b7ea896155c7 =
[
    [ "KLogger.cs", "_k_logger_8cs_source.html", null ],
    [ "KTextWriter.cs", "_k_text_writer_8cs_source.html", null ]
];