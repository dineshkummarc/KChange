var class_k_change_logger_1_1_utilities_1_1_k_logger =
[
    [ "Log", "class_k_change_logger_1_1_utilities_1_1_k_logger.html#ae32cb6e549e5b236c5b3f136a8b09e01", null ]
];