var class_k_change_logger_1_1_maintenance_form_edit =
[
    [ "MaintenanceFormEdit", "class_k_change_logger_1_1_maintenance_form_edit.html#a43e37252615325d98f4c414b3f928290", null ],
    [ "BindControls", "class_k_change_logger_1_1_maintenance_form_edit.html#a74e246ed5fd09e0adb83722bd446db9e", null ],
    [ "button1_Click", "class_k_change_logger_1_1_maintenance_form_edit.html#a160536747fe26d176b12ca58334cce1e", null ],
    [ "button2_Click", "class_k_change_logger_1_1_maintenance_form_edit.html#a613f5f15b9f8daeea96c34905c0643c9", null ],
    [ "Dispose", "class_k_change_logger_1_1_maintenance_form_edit.html#ae3ce9ebaa1eeffff67c833130c1868f0", null ],
    [ "InitializeComponent", "class_k_change_logger_1_1_maintenance_form_edit.html#adc0bb339fc2a1b304827bd5b2ccbdd79", null ],
    [ "button1", "class_k_change_logger_1_1_maintenance_form_edit.html#aefcf1a9dd8558decfe6a545ca6097ae4", null ],
    [ "button2", "class_k_change_logger_1_1_maintenance_form_edit.html#a1219b349185cafd152b2165e2be0fede", null ],
    [ "components", "class_k_change_logger_1_1_maintenance_form_edit.html#ab68081f117f91848fab6b88a246eb994", null ],
    [ "label1", "class_k_change_logger_1_1_maintenance_form_edit.html#ad2807c9bbc279dc28501b2f2cf569e2a", null ],
    [ "label2", "class_k_change_logger_1_1_maintenance_form_edit.html#a3bd639edb3341fdf7a54192e7bc0d938", null ],
    [ "label3", "class_k_change_logger_1_1_maintenance_form_edit.html#ae7aa3b7ad1a6b14ecc4327a6898c0cce", null ],
    [ "label4", "class_k_change_logger_1_1_maintenance_form_edit.html#a8571de52b6dd052f3819f5032ea363ff", null ],
    [ "liLanguage", "class_k_change_logger_1_1_maintenance_form_edit.html#aafb8bc513e36a9787955843e05c6c328", null ],
    [ "myProject", "class_k_change_logger_1_1_maintenance_form_edit.html#a25e1303824ff1d92631dde073f182b8a", null ],
    [ "tbProjectDescription", "class_k_change_logger_1_1_maintenance_form_edit.html#a6063122652779d68f90c309ff93a1c99", null ],
    [ "tbProjectName", "class_k_change_logger_1_1_maintenance_form_edit.html#a0b5e5a3d78907ab5a5d39c209bd4aa2e", null ],
    [ "tbProjectPath", "class_k_change_logger_1_1_maintenance_form_edit.html#ad8a41d29b6212f145e859695d8866b6b", null ]
];