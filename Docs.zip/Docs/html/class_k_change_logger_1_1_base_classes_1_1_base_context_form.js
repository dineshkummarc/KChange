var class_k_change_logger_1_1_base_classes_1_1_base_context_form =
[
    [ "BaseContextForm", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html#a79755d87717fd3b1f630b46f0faa575d", null ],
    [ "Dispose", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html#aa775e451b35e8074712877a748e63d89", null ],
    [ "InitializeComponent", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html#ad216d8c19c6607b013d90f1cbde25825", null ],
    [ "components", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html#a995f1ff988ef27a4fd0c7e770b8c471a", null ],
    [ "Data", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html#adc07cde18ebe56c2945bcdbbeb2051b6", null ]
];