var class_k_change_logger_1_1_language =
[
    [ "Language", "class_k_change_logger_1_1_language.html#a487dd284242afb523ca1e5f81d5296ba", null ],
    [ "attach_Projects", "class_k_change_logger_1_1_language.html#a1e312cb36aaba2a6ababeca66222783d", null ],
    [ "detach_Projects", "class_k_change_logger_1_1_language.html#a68fcb101349c4396256e2d1f5efeddf4", null ],
    [ "OnCreated", "class_k_change_logger_1_1_language.html#a6ae988274fe26c32a057ef230a365dbb", null ],
    [ "OnDescriptionChanged", "class_k_change_logger_1_1_language.html#a7bb8b6795ad9a89b2d52bc388f139d67", null ],
    [ "OnDescriptionChanging", "class_k_change_logger_1_1_language.html#a38b9fbd30405592301095bbcc295b742", null ],
    [ "OnIDChanged", "class_k_change_logger_1_1_language.html#aed0089f551913e71a1a3c8b3ea0a9178", null ],
    [ "OnIDChanging", "class_k_change_logger_1_1_language.html#a2258ba5282c8ba60d55749639955dd65", null ],
    [ "OnLoaded", "class_k_change_logger_1_1_language.html#a8f951c4a7a1b66748fa64627b6de5f35", null ],
    [ "OnValidate", "class_k_change_logger_1_1_language.html#a1d89881da0375c39f3d529a22c94d317", null ],
    [ "SendPropertyChanged", "class_k_change_logger_1_1_language.html#a0d42f00d44b44f946b17964bc4f1a1ae", null ],
    [ "SendPropertyChanging", "class_k_change_logger_1_1_language.html#a9fe005939ffd4d551016c379f034b385", null ],
    [ "_Description", "class_k_change_logger_1_1_language.html#a27c9a0e64a7e2a6f7d797cf2bffe83a9", null ],
    [ "_ID", "class_k_change_logger_1_1_language.html#a39d8acc6f4ca78ae9ebd2508f4d2f6a8", null ],
    [ "_Projects", "class_k_change_logger_1_1_language.html#ad351c1bd1fb6709a2ed68c1e4566f2be", null ],
    [ "emptyChangingEventArgs", "class_k_change_logger_1_1_language.html#a219c5219119a7d46b717a09f2e96a20b", null ],
    [ "Description", "class_k_change_logger_1_1_language.html#a7a87779b703cdd3d2b8957f13a768730", null ],
    [ "ID", "class_k_change_logger_1_1_language.html#a37d63cb25338bec891a0e43ac5b2d85f", null ],
    [ "Projects", "class_k_change_logger_1_1_language.html#a905d721291a7cdbcb3bc4d647b5e1921", null ],
    [ "PropertyChanged", "class_k_change_logger_1_1_language.html#a8b6aa67bdf6bd685fc95421e0a771e2b", null ],
    [ "PropertyChanging", "class_k_change_logger_1_1_language.html#a69b354c23051095dad5c6668039758aa", null ]
];