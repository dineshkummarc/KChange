var class_k_change_logger_1_1_main_form_projects_new =
[
    [ "MainFormProjectsNew", "class_k_change_logger_1_1_main_form_projects_new.html#ab63a9401c86765eba5146fdea96c6d44", null ],
    [ "BindLanguagesListBox", "class_k_change_logger_1_1_main_form_projects_new.html#a0f4fd199707055e7239af5f78333a673", null ],
    [ "button1_Click", "class_k_change_logger_1_1_main_form_projects_new.html#a5c83aa31732f06f47522473caf2ac388", null ],
    [ "button2_Click", "class_k_change_logger_1_1_main_form_projects_new.html#ae9529981aa81e606947885df6ca29065", null ],
    [ "Dispose", "class_k_change_logger_1_1_main_form_projects_new.html#a053ac2822e873e53e1cb8d922756033e", null ],
    [ "InitializeComponent", "class_k_change_logger_1_1_main_form_projects_new.html#a28d092ab87e81c0d0a1815440cb6a885", null ],
    [ "liLanguage_SelectedIndexChanged", "class_k_change_logger_1_1_main_form_projects_new.html#acc92d3dfa55d2dd7c8637315b7efd7d6", null ],
    [ "button1", "class_k_change_logger_1_1_main_form_projects_new.html#a59357651bcb32ca32a9e439136604d2f", null ],
    [ "button2", "class_k_change_logger_1_1_main_form_projects_new.html#aa42db8cd8b2a27d442e7a32537701b70", null ],
    [ "components", "class_k_change_logger_1_1_main_form_projects_new.html#a54b78d1f3c3453d4625a679363b17675", null ],
    [ "imageList1", "class_k_change_logger_1_1_main_form_projects_new.html#abfaac0778c88ee17374449e5061f03c1", null ],
    [ "label1", "class_k_change_logger_1_1_main_form_projects_new.html#abe63fabad0254716cb0a139efd9bdf74", null ],
    [ "label2", "class_k_change_logger_1_1_main_form_projects_new.html#aaf1a72ae2ef58cb9169aebe65d29c0cb", null ],
    [ "label3", "class_k_change_logger_1_1_main_form_projects_new.html#aff8d304a6a9056a4e84b28404fdcfe59", null ],
    [ "label4", "class_k_change_logger_1_1_main_form_projects_new.html#a40b45b2b578d360edf3e9229e896533b", null ],
    [ "liLanguage", "class_k_change_logger_1_1_main_form_projects_new.html#ad42b4f4522ccdd89321ccdc8519d86ae", null ],
    [ "tbProjectDescription", "class_k_change_logger_1_1_main_form_projects_new.html#a8f6319a64011bfffe8a290dd9168f27e", null ],
    [ "tbProjectName", "class_k_change_logger_1_1_main_form_projects_new.html#aec6a7307a79361e5148c7425ac4ee0d1", null ],
    [ "tbProjectPath", "class_k_change_logger_1_1_main_form_projects_new.html#a390f10095ef90ff6ade68932d9775d29", null ]
];