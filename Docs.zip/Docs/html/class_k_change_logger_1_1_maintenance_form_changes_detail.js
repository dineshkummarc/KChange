var class_k_change_logger_1_1_maintenance_form_changes_detail =
[
    [ "MaintenanceFormChangesDetail", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a5dbfdd536c9d75f317a455861abc5836", null ],
    [ "BindElements", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a78db81799b25ac4a641bf0222ed2ba22", null ],
    [ "ButtonOK_Click", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#adecbaf7900670f9f2cdda8db31dc5b15", null ],
    [ "Dispose", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a8a7eaf671c7936363e46634cbf8c066b", null ],
    [ "InitializeComponent", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#aec7cedae1f32e051aacff0b5818d460b", null ],
    [ "ButtonOK", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#aa5cab2b5dacc3999a217f42761e93162", null ],
    [ "changeChangedByLabel", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#aa51aa46f8e920b55554e8714b0e180e5", null ],
    [ "changeChangedFileLabel", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#ae1b63647ee1284525b9d0e8ef4b75adc", null ],
    [ "changeChangedOnLabel", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a3933fe701934f856b511a6caa2b97161", null ],
    [ "changeDescriptionTextBox", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#aee1afb68c172f764de17e371be40d26d", null ],
    [ "components", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a80890edc28321e9399700adaf71c9843", null ],
    [ "label1", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a40551b212b5cccd9bdfaed20e58a6165", null ],
    [ "label2", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#ab0739c61f48908638d2a7beb757b6c78", null ],
    [ "label3", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a1b4d9d4fba163f565a4a76311e71de99", null ],
    [ "label4", "class_k_change_logger_1_1_maintenance_form_changes_detail.html#a9a434fc8e3026cd5ad798823cdc70513", null ]
];