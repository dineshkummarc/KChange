var namespaces =
[
    [ "KChangeLogger", "namespace_k_change_logger.html", "namespace_k_change_logger" ]
];