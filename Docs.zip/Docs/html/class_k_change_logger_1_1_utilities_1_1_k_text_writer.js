var class_k_change_logger_1_1_utilities_1_1_k_text_writer =
[
    [ "WriteCSV", "class_k_change_logger_1_1_utilities_1_1_k_text_writer.html#afcf38ffe4e346cc32fb478039238515b", null ],
    [ "WriteTXT", "class_k_change_logger_1_1_utilities_1_1_k_text_writer.html#a4a8b8168ff71156c4a01c621bfa56312", null ]
];