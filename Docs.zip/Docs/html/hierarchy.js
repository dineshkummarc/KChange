var hierarchy =
[
    [ "DataContext", null, [
      [ "KChangeLogger.KChangeDataContextDataContext", "class_k_change_logger_1_1_k_change_data_context_data_context.html", null ]
    ] ],
    [ "Form", null, [
      [ "KChangeLogger.AboutKChange", "class_k_change_logger_1_1_about_k_change.html", null ],
      [ "KChangeLogger.BaseClasses.BaseContextForm", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html", [
        [ "KChangeLogger.MainFormProjects", "class_k_change_logger_1_1_main_form_projects.html", null ],
        [ "KChangeLogger.MainFormProjectsInfo", "class_k_change_logger_1_1_main_form_projects_info.html", null ],
        [ "KChangeLogger.MainFormProjectsNew", "class_k_change_logger_1_1_main_form_projects_new.html", null ],
        [ "KChangeLogger.MaintenanceForm", "class_k_change_logger_1_1_maintenance_form.html", null ],
        [ "KChangeLogger.MaintenanceFormChanges", "class_k_change_logger_1_1_maintenance_form_changes.html", null ],
        [ "KChangeLogger.MaintenanceFormChangesDetail", "class_k_change_logger_1_1_maintenance_form_changes_detail.html", null ],
        [ "KChangeLogger.MaintenanceFormEdit", "class_k_change_logger_1_1_maintenance_form_edit.html", null ],
        [ "KChangeLogger.MaintenanceFormFiles", "class_k_change_logger_1_1_maintenance_form_files.html", null ],
        [ "KChangeLogger.MaintenanceFormFilesAdd", "class_k_change_logger_1_1_maintenance_form_files_add.html", null ]
      ] ],
      [ "KChangeLogger.MainForm", "class_k_change_logger_1_1_main_form.html", null ]
    ] ],
    [ "INotifyPropertyChanged", null, [
      [ "KChangeLogger.Change_Type", "class_k_change_logger_1_1_change___type.html", null ],
      [ "KChangeLogger.Language", "class_k_change_logger_1_1_language.html", null ],
      [ "KChangeLogger.Log", "class_k_change_logger_1_1_log.html", null ],
      [ "KChangeLogger.Log_Type", "class_k_change_logger_1_1_log___type.html", null ],
      [ "KChangeLogger.Project", "class_k_change_logger_1_1_project.html", null ],
      [ "KChangeLogger.Project_Change", "class_k_change_logger_1_1_project___change.html", null ],
      [ "KChangeLogger.Project_File", "class_k_change_logger_1_1_project___file.html", null ]
    ] ],
    [ "INotifyPropertyChanging", null, [
      [ "KChangeLogger.Change_Type", "class_k_change_logger_1_1_change___type.html", null ],
      [ "KChangeLogger.Language", "class_k_change_logger_1_1_language.html", null ],
      [ "KChangeLogger.Log", "class_k_change_logger_1_1_log.html", null ],
      [ "KChangeLogger.Log_Type", "class_k_change_logger_1_1_log___type.html", null ],
      [ "KChangeLogger.Project", "class_k_change_logger_1_1_project.html", null ],
      [ "KChangeLogger.Project_Change", "class_k_change_logger_1_1_project___change.html", null ],
      [ "KChangeLogger.Project_File", "class_k_change_logger_1_1_project___file.html", null ]
    ] ],
    [ "KChangeLogger.Utilities.KLogger", "class_k_change_logger_1_1_utilities_1_1_k_logger.html", null ],
    [ "KChangeLogger.Utilities.KTextWriter", "class_k_change_logger_1_1_utilities_1_1_k_text_writer.html", null ],
    [ "KChangeLogger.Program", "class_k_change_logger_1_1_program.html", null ]
];