var dir_bea6137d0375f416ded2b19eface9641 =
[
    [ "AboutKChange.cs", "_about_k_change_8cs_source.html", null ],
    [ "AboutKChange.Designer.cs", "_about_k_change_8_designer_8cs_source.html", null ]
];