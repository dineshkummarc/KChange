var class_k_change_logger_1_1_change___type =
[
    [ "Change_Type", "class_k_change_logger_1_1_change___type.html#aa4865b20e2195945224b021b0fa30055", null ],
    [ "attach_Project_Changes", "class_k_change_logger_1_1_change___type.html#a7c803aedc21073170517dbf45a554315", null ],
    [ "detach_Project_Changes", "class_k_change_logger_1_1_change___type.html#aee89fd6db5889040beb9759b9746e219", null ],
    [ "OnCreated", "class_k_change_logger_1_1_change___type.html#ac1ccfc0b5327b5b41de9c1c5c3464d03", null ],
    [ "OnDescriptionChanged", "class_k_change_logger_1_1_change___type.html#aa35f852e35d3cb6c732a4644cbdda45f", null ],
    [ "OnDescriptionChanging", "class_k_change_logger_1_1_change___type.html#a1db1aa4f42f75401b7f1f40c412fcb2f", null ],
    [ "OnIDChanged", "class_k_change_logger_1_1_change___type.html#a2f2e8fd8007b528f11682444de14acc8", null ],
    [ "OnIDChanging", "class_k_change_logger_1_1_change___type.html#a08ac7c546919a916a897be3b344f1b61", null ],
    [ "OnLoaded", "class_k_change_logger_1_1_change___type.html#a4333a885ae3455a67add440c440ef9cf", null ],
    [ "OnValidate", "class_k_change_logger_1_1_change___type.html#a7e24ce35b911498a2a33811dfd1a7e39", null ],
    [ "SendPropertyChanged", "class_k_change_logger_1_1_change___type.html#a9df8bc15e525292e02580d4888badd0a", null ],
    [ "SendPropertyChanging", "class_k_change_logger_1_1_change___type.html#a7b5a2af06653680c347150dab7388767", null ],
    [ "_Description", "class_k_change_logger_1_1_change___type.html#abdb1cd62757ff76b841331a53575f309", null ],
    [ "_ID", "class_k_change_logger_1_1_change___type.html#ac90893f6f0bdc6f8d0697da867d79917", null ],
    [ "_Project_Changes", "class_k_change_logger_1_1_change___type.html#adbd2dbb85d51822e86d3f4bbfc4fe032", null ],
    [ "emptyChangingEventArgs", "class_k_change_logger_1_1_change___type.html#ae617757fe04ffb79763ae3ab20a89d63", null ],
    [ "Description", "class_k_change_logger_1_1_change___type.html#a8824668ad26ce2508c727b979384f449", null ],
    [ "ID", "class_k_change_logger_1_1_change___type.html#ae591ed66ae32b99d9d13e736db1268f6", null ],
    [ "Project_Changes", "class_k_change_logger_1_1_change___type.html#a4dbd0ac05c534967bd0a0ebd5803f83b", null ],
    [ "PropertyChanged", "class_k_change_logger_1_1_change___type.html#a6e7e294d3d632791c62a0eb9872efd99", null ],
    [ "PropertyChanging", "class_k_change_logger_1_1_change___type.html#a9574f73c45dabf703a5a97dd6cc5dabb", null ]
];