var dir_f2eacb7b3f2a298e60041c0dc5fb7770 =
[
    [ "MainFormProjects.cs", "_main_form_projects_8cs_source.html", null ],
    [ "MainFormProjects.Designer.cs", "_main_form_projects_8_designer_8cs_source.html", null ],
    [ "MainFormProjectsInfo.cs", "_main_form_projects_info_8cs_source.html", null ],
    [ "MainFormProjectsInfo.Designer.cs", "_main_form_projects_info_8_designer_8cs_source.html", null ],
    [ "MainFormProjectsNew.cs", "_main_form_projects_new_8cs_source.html", null ],
    [ "MainFormProjectsNew.Designer.cs", "_main_form_projects_new_8_designer_8cs_source.html", null ]
];