var namespace_k_change_logger_1_1_base_classes =
[
    [ "BaseContextForm", "class_k_change_logger_1_1_base_classes_1_1_base_context_form.html", "class_k_change_logger_1_1_base_classes_1_1_base_context_form" ]
];