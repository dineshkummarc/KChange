var files =
[
    [ "KChangeLogger", "dir_a00241f3684297a3655c06063091fe01.html", "dir_a00241f3684297a3655c06063091fe01" ]
];