var namespace_k_change_logger_1_1_utilities =
[
    [ "KLogger", "class_k_change_logger_1_1_utilities_1_1_k_logger.html", "class_k_change_logger_1_1_utilities_1_1_k_logger" ],
    [ "KTextWriter", "class_k_change_logger_1_1_utilities_1_1_k_text_writer.html", "class_k_change_logger_1_1_utilities_1_1_k_text_writer" ]
];