var class_k_change_logger_1_1_program =
[
    [ "Main", "class_k_change_logger_1_1_program.html#abf4d299b9a86819ede3d42a52fbb8b80", null ]
];