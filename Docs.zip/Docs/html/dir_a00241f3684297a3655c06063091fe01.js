var dir_a00241f3684297a3655c06063091fe01 =
[
    [ "BaseClasses", "dir_970f7fe3a595f41789b1aa4c340db5b5.html", "dir_970f7fe3a595f41789b1aa4c340db5b5" ],
    [ "Forms", "dir_c1675bf23fca5d778db1fc7cf3418a0e.html", "dir_c1675bf23fca5d778db1fc7cf3418a0e" ],
    [ "Properties", "dir_7456cf9797461f60116424bc2378bb4a.html", "dir_7456cf9797461f60116424bc2378bb4a" ],
    [ "Utilities", "dir_00a5e4a5e8534d623703b7ea896155c7.html", "dir_00a5e4a5e8534d623703b7ea896155c7" ],
    [ "KChangeDataContext.cs", "_k_change_data_context_8cs_source.html", null ],
    [ "KChangeDataContext.designer.cs", "_k_change_data_context_8designer_8cs_source.html", null ],
    [ "Program.cs", "_program_8cs_source.html", null ]
];