var searchData=
[
  ['aboutkchange',['AboutKChange',['../class_k_change_logger_1_1_about_k_change.html',1,'KChangeLogger']]]
];
