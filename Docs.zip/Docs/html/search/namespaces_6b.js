var searchData=
[
  ['baseclasses',['BaseClasses',['../namespace_k_change_logger_1_1_base_classes.html',1,'KChangeLogger']]],
  ['kchangelogger',['KChangeLogger',['../namespace_k_change_logger.html',1,'']]],
  ['properties',['Properties',['../namespace_k_change_logger_1_1_properties.html',1,'KChangeLogger']]],
  ['utilities',['Utilities',['../namespace_k_change_logger_1_1_utilities.html',1,'KChangeLogger']]]
];
