var searchData=
[
  ['editbutton_5fclick',['EditButton_Click',['../class_k_change_logger_1_1_maintenance_form.html#a32415e75480fcab9ce6250bd60611b5b',1,'KChangeLogger::MaintenanceForm']]],
  ['exittoolstripmenuitem_5fclick',['exitToolStripMenuItem_Click',['../class_k_change_logger_1_1_main_form.html#a5294cb70b391c0d6458459db8faf34de',1,'KChangeLogger::MainForm']]]
];
