var searchData=
[
  ['newbutton_5fclick',['NewButton_Click',['../class_k_change_logger_1_1_main_form_projects.html#a394a582d0f0fb8f97eeed9ac73e7bac7',1,'KChangeLogger::MainFormProjects']]]
];
