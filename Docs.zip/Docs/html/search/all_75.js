var searchData=
[
  ['updateprojectlabel',['UpdateProjectLabel',['../class_k_change_logger_1_1_main_form.html#ac378142317f33c673b0fe51d458787f3',1,'KChangeLogger::MainForm']]]
];
