var searchData=
[
  ['program',['Program',['../class_k_change_logger_1_1_program.html',1,'KChangeLogger']]],
  ['project',['Project',['../class_k_change_logger_1_1_project.html',1,'KChangeLogger']]],
  ['project_5fchange',['Project_Change',['../class_k_change_logger_1_1_project___change.html',1,'KChangeLogger']]],
  ['project_5ffile',['Project_File',['../class_k_change_logger_1_1_project___file.html',1,'KChangeLogger']]],
  ['projectsgv_5fcelldoubleclick',['ProjectsGV_CellDoubleClick',['../class_k_change_logger_1_1_main_form_projects.html#abfb59861d01b338d2ebf1b647e38c81d',1,'KChangeLogger::MainFormProjects']]],
  ['projectstoolstripmenuitem_5fclick',['projectsToolStripMenuItem_Click',['../class_k_change_logger_1_1_main_form.html#a8fd865c99e0da0ba9d7ad8db910494a9',1,'KChangeLogger::MainForm']]]
];
