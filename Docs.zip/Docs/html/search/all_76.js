var searchData=
[
  ['validatechangeinput',['ValidateChangeInput',['../class_k_change_logger_1_1_maintenance_form.html#abfe3b0c3e34f548012c786be2342ae86',1,'KChangeLogger::MaintenanceForm']]]
];
