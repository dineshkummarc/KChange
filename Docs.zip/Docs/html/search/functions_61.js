var searchData=
[
  ['aboutkchangeloggertoolstripmenuitem_5fclick',['aboutKChangeLoggerToolStripMenuItem_Click',['../class_k_change_logger_1_1_main_form.html#af562c1fdee628a0bcb41a9e7d0b64859',1,'KChangeLogger::MainForm']]],
  ['addfile',['AddFile',['../class_k_change_logger_1_1_k_change_data_context_data_context.html#acdb5f1455ee36fed7d43decc8c25451c',1,'KChangeLogger::KChangeDataContextDataContext']]],
  ['addlog',['AddLog',['../class_k_change_logger_1_1_k_change_data_context_data_context.html#ab8c5a90ec61abdcc352136fbe3aa4900',1,'KChangeLogger::KChangeDataContextDataContext']]],
  ['addproject',['AddProject',['../class_k_change_logger_1_1_k_change_data_context_data_context.html#ac22d62bcf0766fea09b0b39d10332bd6',1,'KChangeLogger::KChangeDataContextDataContext']]]
];
