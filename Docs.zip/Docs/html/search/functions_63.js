var searchData=
[
  ['cancelbutton_5fclick',['CancelButton_Click',['../class_k_change_logger_1_1_main_form_projects.html#a6bcd930ec84a32e6a220e59fd078a185',1,'KChangeLogger::MainFormProjects']]],
  ['changesbutton_5fclick',['ChangesButton_Click',['../class_k_change_logger_1_1_maintenance_form.html#a42f7170d9e41e2553abebced796d283c',1,'KChangeLogger::MaintenanceForm']]],
  ['changesgv_5fcelldoubleclick',['ChangesGV_CellDoubleClick',['../class_k_change_logger_1_1_maintenance_form_changes.html#a0b6d00d98fc832f348df92cab0584b6e',1,'KChangeLogger::MaintenanceFormChanges']]],
  ['clearcontrols',['ClearControls',['../class_k_change_logger_1_1_maintenance_form.html#ae96dd0ada3f6f91c1250bd85c8eb09ef',1,'KChangeLogger::MaintenanceForm']]]
];
