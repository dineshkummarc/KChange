var searchData=
[
  ['change_5ftype',['Change_Type',['../class_k_change_logger_1_1_change___type.html',1,'KChangeLogger']]]
];
