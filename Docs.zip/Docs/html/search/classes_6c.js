var searchData=
[
  ['language',['Language',['../class_k_change_logger_1_1_language.html',1,'KChangeLogger']]],
  ['log',['Log',['../class_k_change_logger_1_1_log.html',1,'KChangeLogger']]],
  ['log_5ftype',['Log_Type',['../class_k_change_logger_1_1_log___type.html',1,'KChangeLogger']]]
];
