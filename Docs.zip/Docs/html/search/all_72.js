var searchData=
[
  ['refreshbutton_5fclick',['RefreshButton_Click',['../class_k_change_logger_1_1_main_form_projects.html#a194fc7933e0f1418ae641a5cbbc225e6',1,'KChangeLogger::MainFormProjects']]],
  ['refreshgridview',['RefreshGridView',['../class_k_change_logger_1_1_main_form_projects.html#ae15a6379717191a44cb10caa1557fbf9',1,'KChangeLogger::MainFormProjects']]],
  ['removefile',['RemoveFile',['../class_k_change_logger_1_1_k_change_data_context_data_context.html#a47e20112e74e6de15c91f025ddfc909e',1,'KChangeLogger::KChangeDataContextDataContext']]],
  ['removeproject',['RemoveProject',['../class_k_change_logger_1_1_k_change_data_context_data_context.html#a6c42cb8a091ae63b3e7d25bcef13068d',1,'KChangeLogger::KChangeDataContextDataContext']]],
  ['resizecolumns',['ResizeColumns',['../class_k_change_logger_1_1_main_form_projects.html#ac3a7eca526c10a839cc70b9c0a0d3666',1,'KChangeLogger::MainFormProjects']]]
];
