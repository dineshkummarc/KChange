var searchData=
[
  ['kchangedatacontextdatacontext',['KChangeDataContextDataContext',['../class_k_change_logger_1_1_k_change_data_context_data_context.html',1,'KChangeLogger']]],
  ['klogger',['KLogger',['../class_k_change_logger_1_1_utilities_1_1_k_logger.html',1,'KChangeLogger::Utilities']]],
  ['ktextwriter',['KTextWriter',['../class_k_change_logger_1_1_utilities_1_1_k_text_writer.html',1,'KChangeLogger::Utilities']]]
];
