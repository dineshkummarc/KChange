var searchData=
[
  ['program',['Program',['../class_k_change_logger_1_1_program.html',1,'KChangeLogger']]],
  ['project',['Project',['../class_k_change_logger_1_1_project.html',1,'KChangeLogger']]],
  ['project_5fchange',['Project_Change',['../class_k_change_logger_1_1_project___change.html',1,'KChangeLogger']]],
  ['project_5ffile',['Project_File',['../class_k_change_logger_1_1_project___file.html',1,'KChangeLogger']]]
];
