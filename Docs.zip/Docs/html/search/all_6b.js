var searchData=
[
  ['baseclasses',['BaseClasses',['../namespace_k_change_logger_1_1_base_classes.html',1,'KChangeLogger']]],
  ['kchangedatacontextdatacontext',['KChangeDataContextDataContext',['../class_k_change_logger_1_1_k_change_data_context_data_context.html',1,'KChangeLogger']]],
  ['kchangelogger',['KChangeLogger',['../namespace_k_change_logger.html',1,'']]],
  ['klogger',['KLogger',['../class_k_change_logger_1_1_utilities_1_1_k_logger.html',1,'KChangeLogger::Utilities']]],
  ['ktextwriter',['KTextWriter',['../class_k_change_logger_1_1_utilities_1_1_k_text_writer.html',1,'KChangeLogger::Utilities']]],
  ['properties',['Properties',['../namespace_k_change_logger_1_1_properties.html',1,'KChangeLogger']]],
  ['utilities',['Utilities',['../namespace_k_change_logger_1_1_utilities.html',1,'KChangeLogger']]]
];
