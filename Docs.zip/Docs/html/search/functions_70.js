var searchData=
[
  ['projectsgv_5fcelldoubleclick',['ProjectsGV_CellDoubleClick',['../class_k_change_logger_1_1_main_form_projects.html#abfb59861d01b338d2ebf1b647e38c81d',1,'KChangeLogger::MainFormProjects']]],
  ['projectstoolstripmenuitem_5fclick',['projectsToolStripMenuItem_Click',['../class_k_change_logger_1_1_main_form.html#a8fd865c99e0da0ba9d7ad8db910494a9',1,'KChangeLogger::MainForm']]]
];
