var searchData=
[
  ['basecontextform',['BaseContextForm',['../class_k_change_logger_1_1_base_classes_1_1_base_context_form.html',1,'KChangeLogger::BaseClasses']]]
];
