var searchData=
[
  ['data',['Data',['../class_k_change_logger_1_1_main_form.html#a0e90c9a146579eebf64990a1ef2811f4',1,'KChangeLogger::MainForm']]]
];
